using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace FranchiseKPIDashboardV2
{
    public partial class KpiDashboardForm : Form
    {
        public KpiDashboardForm()
        {
            InitializeComponent();
            SetupChart();
        }

        private void SetupChart()
        {
            Chart salesChart = new Chart();
            salesChart.Dock = DockStyle.Top;
            salesChart.Height = 300;

            ChartArea chartArea = new ChartArea();
            salesChart.ChartAreas.Add(chartArea);

            Series series = new Series("Sales");
            series.ChartType = SeriesChartType.Column;
            series.Points.AddXY("Mon", 100);
            series.Points.AddXY("Tue", 80);
            series.Points.AddXY("Wed", 90);
            series.Points.AddXY("Thu", 70);
            series.Points.AddXY("Fri", 120);

            salesChart.Series.Add(series);
            this.Controls.Add(salesChart);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label titleLabel = new Label();
            titleLabel.Text = "Weekly Franchise Sales Report";
            titleLabel.Top = 330;
            titleLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            titleLabel.Dock = DockStyle.Top;
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            titleLabel.Height = 40;
            this.Controls.Add(titleLabel);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button btnExport = new Button();
            btnExport.Text = "Export to PDF";
            btnExport.Top = 200;
            btnExport.Left = (this.ClientSize.Width / 2) - 10;
            btnExport.Width = 120;
            this.Controls.Add(btnExport);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Button btnExcel = new Button();
            btnExcel.Text = "Load from Excel";
            btnExcel.Top = 200;
            btnExcel.Left = (this.ClientSize.Width / 2) - 140; 
            btnExcel.Width = 120;
            this.Controls.Add(btnExcel);

        }

        private void btnChart_Click(object sender, EventArgs e)
        {
            Button btnChart = new Button();
            btnChart.Text = "Refresh Chart";
            btnChart.Top = 200;
            btnChart.Left = (this.ClientSize.Width / 2) + 270;
            btnChart.Width = 120;
            this.Controls.Add(btnChart);

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Button btnExit = new Button();
            btnExit.Text = "Exit";
            btnExit.Top = 200;
            btnExit.Left = (this.ClientSize.Width / 2) - 400;
            btnExit.Click += (s, args) => this.Close();
            this.Controls.Add(btnExit);

        }
    }
}
