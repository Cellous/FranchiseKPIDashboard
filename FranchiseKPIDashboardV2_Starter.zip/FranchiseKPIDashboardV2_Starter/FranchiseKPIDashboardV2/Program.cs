using System;
using System.Windows.Forms;

namespace FranchiseKPIDashboardV2
{
    public partial class KpiDashboardForm : Form
    {



        static class Program
        {
            [STAThread]
            static void Main()
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new KpiDashboardForm());
            }
        }
    }
}
